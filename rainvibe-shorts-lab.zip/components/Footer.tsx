
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900/30 mt-12 py-6 text-center text-slate-400 text-sm">
      <div className="container mx-auto px-4">
        <p>&copy; {new Date().getFullYear()} RainVibe Shorts Lab. Powered by AI.</p>
        <p className="mt-1">Create your next viral hit with the power of generative AI.</p>
      </div>
    </footer>
  );
};

export default Footer;
