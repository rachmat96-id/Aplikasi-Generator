export interface GeneratorFormState {
  goal: string;
  mood: string;
  duration: string;
  visual: string;
  characterDescription: string;
  sound: string;
  tools: string[];
  manualInput: string;
}

export interface GeneratedIdea {
  title: string;
  hook: string;
  visualDescription: {
    scene: string;
    description: string;
    aiImagePrompt: string;
    aiVideoPrompt: string;
  }[];
  aiPrompt: string;
  soundScript: string;
  hashtags: string[];
  postingTime: string;
}

export interface LibraryItem {
  id: number;
  category: string;
  title: string;
  hashtags: string;
  videoUrl: string;
}