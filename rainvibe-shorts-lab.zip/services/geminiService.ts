
import { GoogleGenAI, Type } from "@google/genai";
import type { GeneratorFormState, GeneratedIdea } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateShortsIdea = async (formData: GeneratorFormState): Promise<GeneratedIdea> => {
    
  const totalDuration = parseInt(formData.duration, 10) || 30; // Default to 30s if input is invalid
  const numberOfScenes = Math.max(2, Math.ceil(totalDuration / 9)); // Calculate scenes for ~8-10s each

  const dynamicResponseSchema = {
      type: Type.OBJECT,
      properties: {
          title: {
              type: Type.STRING,
              description: 'Judul video YouTube Shorts yang viral-friendly, menarik, dan dalam Bahasa Indonesia.'
          },
          hook: {
              type: Type.STRING,
              description: 'Hook pembuka yang sangat menarik untuk 5 detik pertama video, dalam Bahasa Indonesia.'
          },
          visualDescription: {
              type: Type.ARRAY,
              description: `Deskripsi visual lengkap per adegan dalam Bahasa Indonesia. Buat tepat ${numberOfScenes} adegan, di mana setiap adegan berdurasi sekitar 8-10 detik.`,
              items: {
                  type: Type.OBJECT,
                  properties: {
                      scene: { type: Type.STRING, description: 'Nama adegan dan perkiraan penanda waktu, contoh: "Adegan 1 (0-8 detik)".' },
                      description: { type: Type.STRING, description: 'Deskripsi detail elemen visual di adegan ini.' },
                      aiImagePrompt: { type: Type.STRING, description: 'Prompt efektif untuk AI image generator (seperti Midjourney, DALL-E) dalam Bahasa Inggris untuk menciptakan gambar untuk adegan ini.' },
                      aiVideoPrompt: { type: Type.STRING, description: 'Prompt efektif untuk AI video generator (seperti Sora, Runway) dalam Bahasa Inggris untuk menciptakan klip video untuk adegan ini.' }
                  },
                  required: ['scene', 'description', 'aiImagePrompt', 'aiVideoPrompt']
              }
          },
          aiPrompt: {
              type: Type.STRING,
              description: 'Prompt detail dan efektif untuk AI video/image generator (seperti Sora, Runway, Pika) dalam Bahasa Inggris, untuk menciptakan visual yang dideskripsikan. Gabungkan semua deskripsi adegan menjadi satu prompt sinematik yang koheren.'
          },
          soundScript: {
              type: Type.STRING,
              description: 'Deskripsi detail untuk sound cue, efek suara utama dan pendukung, serta script narasi ASMR jika diperlukan, dalam Bahasa Indonesia.'
          },
          hashtags: {
              type: Type.ARRAY,
              description: 'Daftar 10-15 hashtag viral dan relevan untuk SEO YouTube Shorts.',
              items: { type: Type.STRING }
          },
          postingTime: {
              type: Type.STRING,
              description: 'Saran waktu dan hari terbaik untuk posting video beserta alasannya, dalam Bahasa Indonesia.'
          }
      },
      required: ['title', 'hook', 'visualDescription', 'aiPrompt', 'soundScript', 'hashtags', 'postingTime']
  };

  const characterPromptPart = formData.characterDescription
    ? `\n    - Deskripsi Karakter: ${formData.characterDescription}`
    : '';

  const manualInputPromptPart = formData.manualInput 
    ? `\n    - Instruksi Manual Tambahan: ${formData.manualInput}` 
    : '';

  const prompt = `
    Anda adalah seorang direktur kreatif ahli YouTube Shorts, spesialis konten ASMR hujan yang viral. Tugas Anda adalah membuat rencana konten lengkap berdasarkan spesifikasi pengguna.

    Spesifikasi Pengguna:
    - Tujuan Video: ${formData.goal}
    - Mood & Tema: ${formData.mood}
    - Durasi Target: ${formData.duration} detik
    - Elemen Visual Utama: ${formData.visual}${characterPromptPart}
    - Elemen Suara Utama: ${formData.sound}
    - AI Tools yang Digunakan: ${formData.tools.join(', ')}${manualInputPromptPart}

    Berdasarkan data di atas, hasilkan ide konten yang lengkap.
    
    PENTING:
    1. Bagi video menjadi tepat ${numberOfScenes} adegan. Setiap adegan harus memiliki durasi sekitar 8-10 detik untuk mencapai total durasi target.
    2. KONSISTENSI KARAKTER ADALAH PRIORITAS UTAMA: Jika deskripsi karakter disediakan, pastikan karakter yang sama persis muncul di setiap adegan. Konsistensi ini harus mencakup SEMUA detail: detail wajah (bentuk mata, hidung, bibir), detail tubuh (postur, tinggi badan), dan detail pakaian (jenis, warna, gaya, bahkan lipatan kain). Setiap prompt AI yang dihasilkan harus secara eksplisit bertujuan untuk mereplikasi karakter yang sama persis.
    3. Selain karakter, jaga juga konsistensi kuat pada elemen lain seperti latar belakang, pencahayaan, palet warna, dan suasana keseluruhan. Semua harus terasa menyatu dan berkelanjutan dari satu adegan ke adegan berikutnya untuk menciptakan narasi visual yang koheren dan imersif.

    Fokus untuk membuat konten yang sangat menarik dan berpotensi viral di platform YouTube Shorts.
  `;

  try {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: dynamicResponseSchema,
            temperature: 0.8,
        }
    });
    
    const responseText = response.text.trim();
    const parsedJson = JSON.parse(responseText);

    if (isGeneratedIdea(parsedJson)) {
        return parsedJson;
    } else {
        console.error("Parsed JSON does not match GeneratedIdea interface:", parsedJson);
        throw new Error("Format respons AI tidak valid.");
    }

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Gagal menghasilkan ide dari AI: ${error.message}`);
    }
    throw new Error("Terjadi kesalahan yang tidak diketahui saat menghubungi AI.");
  }
};

function isGeneratedIdea(obj: any): obj is GeneratedIdea {
    return (
        typeof obj === 'object' &&
        obj !== null &&
        typeof obj.title === 'string' &&
        typeof obj.hook === 'string' &&
        Array.isArray(obj.visualDescription) &&
        obj.visualDescription.every((item: any) =>
            typeof item === 'object' &&
            item !== null &&
            typeof item.scene === 'string' &&
            typeof item.description === 'string' &&
            typeof item.aiImagePrompt === 'string' &&
            typeof item.aiVideoPrompt === 'string'
        ) &&
        typeof obj.aiPrompt === 'string' &&
        typeof obj.soundScript === 'string' &&
        Array.isArray(obj.hashtags) &&
        typeof obj.postingTime === 'string'
    );
}
