
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { SparklesIcon } from '../components/icons/SparklesIcon';

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="text-center flex flex-col items-center justify-center h-full pt-16">
      <div className="relative mb-6">
          <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-cyan-400 rounded-full blur opacity-50"></div>
          <div className="relative p-4 bg-slate-800 rounded-full">
            <SparklesIcon className="w-16 h-16 text-cyan-300" />
          </div>
      </div>
      <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white mb-4">
        Welcome to <span className="text-cyan-400">RainVibe Shorts Lab</span>
      </h1>
      <p className="max-w-3xl text-lg md:text-xl text-slate-300 mx-auto mb-8">
        Temukan dan buat ide YouTube Shorts ASMR hujan yang viral — semua dengan kekuatan AI.
      </p>
      <button
        onClick={() => navigate('/generator')}
        className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-bold text-white bg-slate-800 rounded-lg overflow-hidden transition-all duration-300 ease-in-out hover:scale-105"
      >
        <span className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-cyan-400 rounded-lg blur opacity-75 group-hover:opacity-100 transition-opacity duration-300"></span>
        <span className="relative flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            Mulai Buat Ide
        </span>
      </button>
    </div>
  );
};

export default HomePage;
