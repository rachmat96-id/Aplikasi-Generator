import React, { useState, useCallback } from 'react';
import { GeneratorFormState, GeneratedIdea } from '../types';
import { AI_TOOLS } from '../constants';
import { generateShortsIdea } from '../services/geminiService';
import { SparklesIcon } from '../components/icons/SparklesIcon';
import { CopyIcon } from '../components/icons/CopyIcon';
import { EditIcon } from '../components/icons/EditIcon';
import { CheckIcon } from '../components/icons/CheckIcon';
import { RotateCcwIcon } from '../components/icons/RotateCcwIcon';

const initialFormData: GeneratorFormState = {
  goal: 'Relaksasi mendalam dan bantuan tidur',
  mood: 'Tenang dan syahdu',
  duration: '30',
  visual: 'Pondok bambu di tengah hutan hujan',
  characterDescription: 'Wanita muda Asia, sekitar 25 tahun, rambut hitam panjang, mengenakan sweater longgar berwarna krem yang nyaman.',
  sound: 'Gerimis lembut di atap seng dan dedaunan',
  tools: ['Sora', 'ElevenLabs'],
  manualInput: '',
};

const GeneratorPage: React.FC = () => {
  const [formData, setFormData] = useState<GeneratorFormState>(initialFormData);
  const [generatedIdea, setGeneratedIdea] = useState<GeneratedIdea | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedPrompt, setCopiedPrompt] = useState<string | null>(null);
  const [editingPrompt, setEditingPrompt] = useState<{ sceneIndex: number; type: 'image' | 'video' } | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleToolChange = (tool: string) => {
    setFormData(prev => {
      const newTools = prev.tools.includes(tool)
        ? prev.tools.filter(t => t !== tool)
        : [...prev.tools, tool];
      return { ...prev, tools: newTools };
    });
  };

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setGeneratedIdea(null);
    try {
      const idea = await generateShortsIdea(formData);
      setGeneratedIdea(idea);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [formData]);

  const handleReset = useCallback(() => {
    // Mengembalikan semua input pada form "AI Content Generator" ke nilai awal.
    setFormData(initialFormData);
    
    // Membersihkan hasil AI, pesan error, dan status loading di panel kanan.
    setGeneratedIdea(null);
    setError(null);
    setIsLoading(false);
    
    // Mereset status sementara pada UI seperti indikator salin dan edit.
    setCopiedPrompt(null);
    setEditingPrompt(null);
  }, []);
  
  const handleCopyPrompt = (text: string, identifier: string) => {
    navigator.clipboard.writeText(text).then(() => {
        setCopiedPrompt(identifier);
        setTimeout(() => setCopiedPrompt(null), 2000);
    }).catch(err => {
        console.error('Failed to copy text: ', err);
    });
  };

  const handlePromptChange = (e: React.ChangeEvent<HTMLTextAreaElement>, sceneIndex: number, type: 'image' | 'video') => {
      const newText = e.target.value;
      setGeneratedIdea(prev => {
          if (!prev) return null;
          
          const updatedVisualDescription = prev.visualDescription.map((item, index) => {
              if (index === sceneIndex) {
                  return type === 'image' 
                    ? { ...item, aiImagePrompt: newText }
                    : { ...item, aiVideoPrompt: newText };
              }
              return item;
          });

          return { ...prev, visualDescription: updatedVisualDescription };
      });
  };

  const handleEditBlur = () => {
      setEditingPrompt(null);
  };

  const handleTextAreaInput = (e: React.FormEvent<HTMLTextAreaElement>) => {
      const textarea = e.currentTarget;
      textarea.style.height = 'auto';
      textarea.style.height = `${textarea.scrollHeight}px`;
  };

  const renderLoadingSkeleton = () => (
    <div className="animate-pulse space-y-6">
      <div className="h-8 bg-slate-700 rounded w-1/2"></div>
      <div className="space-y-3">
        <div className="h-4 bg-slate-700 rounded w-full"></div>
        <div className="h-4 bg-slate-700 rounded w-5/6"></div>
      </div>
      <div className="h-6 bg-slate-700 rounded w-1/4"></div>
      <div className="space-y-3">
        <div className="h-4 bg-slate-700 rounded w-full"></div>
        <div className="h-4 bg-slate-700 rounded w-full"></div>
        <div className="h-4 bg-slate-700 rounded w-3/4"></div>
      </div>
    </div>
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
      <div className="lg:col-span-2">
        <form onSubmit={handleSubmit} className="bg-slate-800/50 p-6 rounded-lg border border-slate-700 space-y-6">
          <h2 className="text-2xl font-bold text-white flex items-center"><SparklesIcon className="w-6 h-6 mr-2 text-cyan-400"/> AI Content Generator</h2>
          
          <div>
            <label htmlFor="goal" className="block text-sm font-medium text-slate-300 mb-1">Tujuan Video</label>
            <input
              type="text"
              id="goal"
              name="goal"
              value={formData.goal}
              onChange={handleInputChange}
              className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-cyan-500 focus:border-cyan-500"
              placeholder="e.g., Relaksasi, Estetika, Cerita pendek"
            />
          </div>

          <div>
            <label htmlFor="mood" className="block text-sm font-medium text-slate-300 mb-1">Mood & Tema</label>
            <input type="text" id="mood" name="mood" value={formData.mood} onChange={handleInputChange} className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-cyan-500 focus:border-cyan-500" placeholder="e.g., Tenang, Sendu, Dramatis" />
          </div>

          <div>
            <label htmlFor="duration" className="block text-sm font-medium text-slate-300 mb-1">Durasi</label>
            <div className="relative">
              <input
                type="text"
                id="duration"
                name="duration"
                value={formData.duration}
                onChange={handleInputChange}
                className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-cyan-500 focus:border-cyan-500 pr-14"
                placeholder="e.g., 30"
              />
              <span className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 pointer-events-none">
                detik
              </span>
            </div>
          </div>
          
           <div>
            <label htmlFor="visual" className="block text-sm font-medium text-slate-300 mb-1">Visual Utama</label>
            <textarea id="visual" name="visual" value={formData.visual} onChange={handleInputChange} rows={2} className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-cyan-500 focus:border-cyan-500" placeholder="e.g., Wanita Asia duduk di tepi jendela"></textarea>
          </div>

          <div>
            <label htmlFor="characterDescription" className="block text-sm font-medium text-slate-300 mb-1">Deskripsi Karakter (Opsional)</label>
            <textarea id="characterDescription" name="characterDescription" value={formData.characterDescription} onChange={handleInputChange} rows={3} className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-cyan-500 focus:border-cyan-500" placeholder="e.g., Wanita muda Asia, rambut hitam panjang, sweater krem"></textarea>
          </div>
          
           <div>
            <label htmlFor="sound" className="block text-sm font-medium text-slate-300 mb-1">Sound Utama</label>
            <textarea id="sound" name="sound" value={formData.sound} onChange={handleInputChange} rows={2} className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-cyan-500 focus:border-cyan-500" placeholder="e.g., Hujan deras, petir, kodok"></textarea>
          </div>

          <div>
            <label htmlFor="manualInput" className="block text-sm font-medium text-slate-300 mb-1">Input Manual (Opsional)</label>
            <textarea id="manualInput" name="manualInput" value={formData.manualInput} onChange={handleInputChange} rows={3} className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-white focus:ring-cyan-500 focus:border-cyan-500" placeholder="Tambahkan instruksi, gaya, atau elemen spesifik lainnya..."></textarea>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">AI Tools yang Dipakai</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {AI_TOOLS.map(tool => (
                <label key={tool} className="flex items-center space-x-2 bg-slate-700 px-3 py-2 rounded-md cursor-pointer hover:bg-slate-600">
                  <input type="checkbox" checked={formData.tools.includes(tool)} onChange={() => handleToolChange(tool)} className="h-4 w-4 rounded text-cyan-500 bg-slate-800 border-slate-600 focus:ring-cyan-600"/>
                  <span className="text-sm">{tool}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4 pt-2">
            <button type="submit" disabled={isLoading} className="w-full flex-grow flex items-center justify-center bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-bold py-3 px-4 rounded-lg hover:from-purple-700 hover:to-cyan-600 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed">
              {isLoading ? 'Generating...' : 'Buat Ide Viral'}
            </button>
            <button 
                type="button" 
                onClick={handleReset} 
                disabled={isLoading}
                title="Reset Form"
                aria-label="Reset form"
                className="p-3 bg-slate-600 text-slate-200 rounded-lg hover:bg-slate-500 transition-colors duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
             >
                <RotateCcwIcon className="w-5 h-5" />
             </button>
          </div>
        </form>
      </div>

      <div className="lg:col-span-3">
        <div className="bg-slate-800/50 p-6 rounded-lg border border-slate-700 min-h-[500px]">
          <h3 className="text-2xl font-bold text-white mb-4">Hasil Generasi AI</h3>
          {isLoading && renderLoadingSkeleton()}
          {error && <div className="text-red-400 bg-red-900/50 p-4 rounded-md">{error}</div>}
          {generatedIdea && !isLoading && (
            <div className="space-y-6 text-slate-200">
              <div>
                <h4 className="font-bold text-xl text-cyan-300 mb-2">{generatedIdea.title}</h4>
                <p className="text-sm italic bg-slate-700/50 p-3 rounded-md">"{generatedIdea.hook}"</p>
              </div>
              <div>
                <h5 className="font-bold text-lg text-white mb-2">Deskripsi Visual per Adegan</h5>
                 <div className="space-y-4">
                  {generatedIdea.visualDescription.map((v, i) => (
                    <div key={i} className="bg-slate-900/50 p-4 rounded-lg border border-slate-700">
                      <p><strong className="text-slate-300">{v.scene}:</strong> {v.description}</p>
                      <div className="mt-3 space-y-3">
                          <div>
                              <div className="flex justify-between items-center mb-1">
                                <h6 className="text-sm font-semibold text-cyan-400">AI Image Prompt:</h6>
                                <div className="flex items-center space-x-2">
                                  <button onClick={() => handleCopyPrompt(v.aiImagePrompt, `image-${i}`)} className="text-slate-400 hover:text-white transition-colors" title="Salin prompt">
                                    {copiedPrompt === `image-${i}` ? <CheckIcon className="w-4 h-4 text-green-400" /> : <CopyIcon className="w-4 h-4" />}
                                  </button>
                                  <button onClick={() => setEditingPrompt({ sceneIndex: i, type: 'image' })} className="text-slate-400 hover:text-white transition-colors" title="Edit prompt">
                                    <EditIcon className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                              {editingPrompt?.sceneIndex === i && editingPrompt?.type === 'image' ? (
                                <textarea
                                  value={v.aiImagePrompt}
                                  onChange={(e) => handlePromptChange(e, i, 'image')}
                                  onBlur={handleEditBlur}
                                  onInput={handleTextAreaInput}
                                  className="text-xs bg-slate-800 p-2 rounded-md font-mono whitespace-pre-wrap w-full border border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 overflow-hidden resize-none"
                                  autoFocus
                                  rows={1}
                                />
                              ) : (
                                <p className="text-xs bg-slate-800 p-2 rounded-md font-mono whitespace-pre-wrap">{v.aiImagePrompt}</p>
                              )}
                          </div>
                          <div>
                              <div className="flex justify-between items-center mb-1">
                                  <h6 className="text-sm font-semibold text-cyan-400">AI Video Prompt:</h6>
                                  <div className="flex items-center space-x-2">
                                      <button onClick={() => handleCopyPrompt(v.aiVideoPrompt, `video-${i}`)} className="text-slate-400 hover:text-white transition-colors" title="Salin prompt">
                                          {copiedPrompt === `video-${i}` ? <CheckIcon className="w-4 h-4 text-green-400" /> : <CopyIcon className="w-4 h-4" />}
                                      </button>
                                      <button onClick={() => setEditingPrompt({ sceneIndex: i, type: 'video' })} className="text-slate-400 hover:text-white transition-colors" title="Edit prompt">
                                          <EditIcon className="w-4 h-4" />
                                      </button>
                                  </div>
                              </div>
                              {editingPrompt?.sceneIndex === i && editingPrompt?.type === 'video' ? (
                                  <textarea
                                      value={v.aiVideoPrompt}
                                      onChange={(e) => handlePromptChange(e, i, 'video')}
                                      onBlur={handleEditBlur}
                                      onInput={handleTextAreaInput}
                                      className="text-xs bg-slate-800 p-2 rounded-md font-mono whitespace-pre-wrap w-full border border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500 overflow-hidden resize-none"
                                      autoFocus
                                      rows={1}
                                  />
                              ) : (
                                  <p className="text-xs bg-slate-800 p-2 rounded-md font-mono whitespace-pre-wrap">{v.aiVideoPrompt}</p>
                              )}
                          </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
               <div>
                <h5 className="font-bold text-lg text-white mb-2">Prompt AI Video / Image (Global)</h5>
                <p className="text-sm bg-slate-900/70 p-3 rounded-md font-mono whitespace-pre-wrap">{generatedIdea.aiPrompt}</p>
              </div>
               <div>
                <h5 className="font-bold text-lg text-white mb-2">Sound Cue & Script Narasi ASMR</h5>
                <p>{generatedIdea.soundScript}</p>
              </div>
               <div>
                <h5 className="font-bold text-lg text-white mb-2">Hashtag Viral & SEO</h5>
                <div className="flex flex-wrap gap-2">
                  {generatedIdea.hashtags.map(h => <span key={h} className="bg-slate-700 text-cyan-300 text-xs font-medium px-2.5 py-1 rounded-full">{h}</span>)}
                </div>
              </div>
              <div>
                <h5 className="font-bold text-lg text-white mb-2">Waktu Terbaik Posting</h5>
                <p>{generatedIdea.postingTime}</p>
              </div>
            </div>
          )}
          {!generatedIdea && !isLoading && !error && (
            <div className="text-center text-slate-400 py-20">
              <p>Isi form di samping dan klik "Buat Ide Viral" untuk memulai.</p>
              <p>Hasil generasi AI akan muncul di sini.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GeneratorPage;