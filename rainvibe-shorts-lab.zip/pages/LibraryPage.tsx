
import React, { useState, useMemo } from 'react';
import { LIBRARY_DATA } from '../constants';

const LibraryPage: React.FC = () => {
  const [filter, setFilter] = useState('all');

  const filteredData = useMemo(() => {
    if (filter === 'all') return LIBRARY_DATA;
    return LIBRARY_DATA.filter(item => item.category === filter);
  }, [filter]);
  
  const categories = ['all', ...Array.from(new Set(LIBRARY_DATA.map(item => item.category)))];

  return (
    <div>
      <h1 className="text-3xl font-bold text-white mb-2">Template & Referensi Viral</h1>
      <p className="text-slate-300 mb-8">Jelajahi ide siap pakai dan contoh video yang sudah terbukti viral.</p>

      <div className="mb-8">
        <div className="flex flex-wrap gap-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium capitalize transition-colors ${
                filter === cat ? 'bg-cyan-500 text-white' : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredData.map(item => (
          <div key={item.id} className="bg-slate-800/50 border border-slate-700 rounded-lg overflow-hidden flex flex-col group transition-all hover:border-cyan-500/50 hover:shadow-2xl hover:shadow-cyan-500/10">
            <div className="aspect-video bg-black">
               <iframe
                className="w-full h-full"
                src={item.videoUrl}
                title={item.title}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
            <div className="p-4 flex-grow flex flex-col">
              <h3 className="font-bold text-lg text-white mb-2 flex-grow">{item.title}</h3>
              <p className="text-sm text-slate-400">{item.hashtags}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LibraryPage;
