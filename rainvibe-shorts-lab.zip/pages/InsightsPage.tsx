
import React from 'react';
import { ChartIcon } from '../components/icons/ChartIcon';

const InsightsPage: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center text-center h-full pt-16">
      <div className="relative mb-6">
        <div className="absolute -inset-1 bg-gradient-to-r from-indigo-600 to-green-400 rounded-full blur opacity-50"></div>
        <div className="relative p-4 bg-slate-800 rounded-full">
          <ChartIcon className="w-16 h-16 text-green-300" />
        </div>
      </div>
      <h1 className="text-4xl font-bold text-white mb-4">Insights & Analytics</h1>
      <p className="max-w-xl text-lg text-slate-300 mx-auto">
        Fitur ini akan segera hadir! Hubungkan akun YouTube Anda untuk menyimpan ide, melihat riwayat, dan mendapatkan rekomendasi tren yang dipersonalisasi.
      </p>
    </div>
  );
};

export default InsightsPage;
