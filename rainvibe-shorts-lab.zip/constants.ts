import type { LibraryItem } from './types';

export const VIDEO_DURATIONS = ["15s", "30s", "45s", "60s"];
export const AI_TOOLS = ["Sora", "Runway", "Kaiber", "Pika", "D-ID", "ElevenLabs", "Suno", "Whisk AI", "Layaran"];

export const LIBRARY_DATA: LibraryItem[] = [
  {
    id: 1,
    category: "aesthetic",
    title: "Rainy Night in a Cyberpunk City",
    hashtags: "#rain #asmr #cyberpunk #aesthetic #neonlights",
    videoUrl: "https://www.youtube.com/embed/BHACKNONj1w"
  },
  {
    id: 2,
    category: "romantis",
    title: "Coffee Shop Window on a Rainy Day",
    hashtags: "#rainyday #coffeeshop #asmr #romance #cozy",
    videoUrl: "https://www.youtube.com/embed/h1x8iN2-A-E"
  },
  {
    id: 3,
    category: "horror",
    title: "Footsteps in the Attic During a Storm",
    hashtags: "#horror #rainstorm #scary #asmr #spooky",
    videoUrl: "https://www.youtube.com/embed/5D-Kk1Gek3M"
  },
  {
    id: 4,
    category: "spiritual",
    title: "Meditating in a Bamboo Forest in the Rain",
    hashtags: "#meditation #spiritual #rain #bambooforest #asmr",
    videoUrl: "https://www.youtube.com/embed/y8-s_4l7y68"
  },
  {
    id: 5,
    category: "aesthetic",
    title: "Reading by the Fireplace as it Rains Outside",
    hashtags: "#cozyvibes #reading #fireplace #rain #asmr",
    videoUrl: "https://www.youtube.com/embed/a-2G-pke6pQ"
  },
  {
    id: 6,
    category: "romantis",
    title: "Walking Under an Umbrella in Paris",
    hashtags: "#paris #rain #romance #love #asmr",
    videoUrl: "https://www.youtube.com/embed/jAXofVPd_cQ"
  }
];